package com.bignerdranch.android.criminalintent;

import android.support.v4.app.Fragment;

public class CrimeListFragment extends Fragment {

    //nothing yet.
}
